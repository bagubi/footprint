# 请在______处使用一行代码或表达式替换
# 请在...处使用一行或多行代码替换
#
# 注意：请不要修改其他已给出代码

import  turtle
turtle.right(-30)
________
turtle.right(60)
turtle.fd(200)
________
turtle.fd(200)
turtle.right(60)
turtle.fd(200)
turtle.right(120)
