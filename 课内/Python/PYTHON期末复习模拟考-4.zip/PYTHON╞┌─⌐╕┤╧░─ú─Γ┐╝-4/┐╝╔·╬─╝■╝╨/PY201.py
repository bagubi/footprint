# 请在______处使用一行代码或表达式替换
# 请在...处使用一行或多行代码替换
#
# 注意：请不要修改其他已给出代码

import turtle
r = 10
dr = 40
head = 90
for i  in range (_____):
    turtle._____
    turtle.circle(r)
    r +=  dr
    turtle._____
    turtle.seth(-head)
    turtle.fd(dr)
    turtle.seth(0)
turtle.done()
