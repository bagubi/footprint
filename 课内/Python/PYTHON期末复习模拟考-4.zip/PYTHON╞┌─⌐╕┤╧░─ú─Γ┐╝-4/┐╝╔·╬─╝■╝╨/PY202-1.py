# 以下代码为提示框架
# 请在...处使用一行或多行代码替换
# 请在______处使用一行代码替换
#
# 注意：提示框架代码可以任意修改，以完成程序功能为准


import jieba

s = input("请输入一段中文，包含逗号和句号：")
words = _________
all_words = {}
max = 0
high_words =''

for i in words:
    ……
print("\n中文词语数是：{}". format(len(words)))
for key in all_words:
    ……
    print("{}:{}".format(key, all_words [key]))
print("出现最多的词是({})：{}次".format(high_words, max))
