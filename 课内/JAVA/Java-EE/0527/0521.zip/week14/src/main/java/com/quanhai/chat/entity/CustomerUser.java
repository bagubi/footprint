package com.quanhai.chat.entity;

import lombok.Data;

@Data
public class CustomerUser {
    private String username;
    private String password;
    private String name;
    private String role;
}

